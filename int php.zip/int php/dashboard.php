<?php include("dbconnect.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h2>All Posts</h2>
    <a href="add_post.php">+ Add New Post</a>
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Content</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>

        <?php
        $sql = "SELECT * FROM posts ORDER BY created_at DESC";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>".$row['id']."</td>
                    <td>".$row['title']."</td>
                    <td>".$row['content']."</td>
                    <td>";

            if (!empty($row['image'])) {
                echo "<img src='uploads/".$row['image']."' width='100'>";
            } else {
                echo "No image";
            }

            echo "</td>
                  <td>
                      <a href='edit_post.php?id=".$row['id']."'>Edit</a> |
                      <a href='delete_post.php?id=".$row['id']."' onclick='return confirm(\"Delete this post?\")'>Delete</a>
                  </td>
                </tr>";
        }
        ?>
    </table>
</body>
</html>
