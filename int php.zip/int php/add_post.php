<?php include("dbconnect.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Post</title>
</head>
<body>
    <h2>Add New Post</h2>
    <form method="POST" action="" enctype="multipart/form-data">
        Title: <input type="text" name="title" required><br><br>
        Content:<br>
        <textarea name="content" rows="5" cols="30" required></textarea><br><br>
        Image: <input type="file" name="image" accept="image/*"><br><br>
        <button type="submit" name="submit">Save Post</button><br><br>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $title = $_POST['title'];
        $content = $_POST['content'];

        // Handle image upload
        $imageName = $_FILES['image']['name'];
        $imageTmp = $_FILES['image']['tmp_name'];
        $imagePath = "uploads/" . basename($imageName);

        if (!empty($imageName)) {
            move_uploaded_file($imageTmp, $imagePath);
        } else {
            $imagePath = ""; // or you can set a default image path
        }

        // Insert into database
        $sql = "INSERT INTO posts (title, content, image) VALUES ('$title', '$content', '$imagePath')";
        if ($conn->query($sql) === TRUE) {
            echo "Post added successfully!";
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
    ?>
</body>
</html>
